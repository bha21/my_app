from kivy.core.window import Window
from kivy.lang import Builder
from kivy.clock import Clock
from kivy.uix.screenmanager import ScreenManager, Screen, SlideTransition
from kivy.metrics import dp

from kivymd.app import MDApp
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.dialog import MDDialog
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.toolbar import MDTopAppBar
from kivymd.uix.menu import MDDropdownMenu
from kivymd.uix.snackbar import Snackbar

from db_manager import (
    create_user,
    verify_user,
    get_user_mpin,
    set_user_mpin,
    is_mpin_expired
)

create_user("admin","1234")
current_username = None  # Track logged-in user
try:
    from kivymd.uix.spinner import MDSpinner
    _SPINNER_AVAILABLE = True
except Exception:
    _SPINNER_AVAILABLE = False
    from kivymd.uix.progressbar import MDProgressBar

Window.borderless = True
Window.size = (350, 600)

VALID_USERNAME = "admin"
VALID_PASSWORD = "1234"

KV = open("main.kv").read()

class LoginScreen(Screen):
    pass

class HomeScreen(Screen):
    pass

class DashboardScreen(Screen):
    pass

class ProfileScreen(Screen):
    pass

class SettingsScreen(Screen):
    pass

class NotificationsScreen(Screen):
    pass

class HelpSupportScreen(Screen):
    pass

class LoadingContent(MDBoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = "vertical"
        self.spacing = dp(12)
        self.padding = dp(12)
        self.adaptive_height = True

        if _SPINNER_AVAILABLE:
            self.add_widget(MDSpinner(size_hint=(None, None), size=(56, 56), determinate=False))
        else:
            self._pb = MDProgressBar(value=0)
            self.add_widget(self._pb)
            self._pb_anim_ev = Clock.schedule_interval(self._animate_pb, 0.02)

        self.add_widget(MDLabel(text="Please wait...", halign="center"))

    def _animate_pb(self, dt):
        v = (self._pb.value + 2) % 101
        self._pb.value = v

    def cleanup(self):
        if not _SPINNER_AVAILABLE and hasattr(self, "_pb_anim_ev"):
            Clock.unschedule(self._pb_anim_ev)

class SetMPINScreen(Screen):
    from_home = False  # Default: first time MPIN

    def on_pre_enter(self, *args):
        self.ids.new_mpin.text = ""
        self.ids.new_mpin.focus = False
        # Show/hide back buttons based on source
        if self.from_home:
            self.ids.back_to_login.opacity = 0
            self.ids.back_to_login.disabled = True
            self.ids.back_to_home.opacity = 1
            self.ids.back_to_home.disabled = False
        else:
            self.ids.back_to_login.opacity = 1
            self.ids.back_to_login.disabled = False
            self.ids.back_to_home.opacity = 0
            self.ids.back_to_home.disabled = True

    def save_mpin(self, mpin):
        username = self.manager.get_screen("login").ids.username.text.strip()

        if not username:
            Snackbar(text="Please login first or enter a username!", duration=2).open()
            return

        if len(mpin) != 4 or not mpin.isdigit():
            Snackbar(text="MPIN must be 4 digits!", duration=2).open()
            return

        set_user_mpin(username, mpin)
        Snackbar(text="MPIN saved successfully!", duration=1).open()

        # Navigate based on source
        if self.from_home:
            self.manager.transition = SlideTransition(direction="left", duration=0.3)
            self.manager.current = "home"
        else:
            self.manager.transition = SlideTransition(direction="left", duration=0.3)
            self.manager.current = "login"

class EnterMPINScreen(Screen):
    def verify_mpin(self, mpin):
        global current_username
        mpin_data = get_user_mpin(username="admin")
        print(mpin_data)
        saved_mpin = mpin_data[0] if mpin_data else None

        if not saved_mpin:
            dialogMpin = MDDialog(
                title="No MPIN Set",
                text="You have not set an MPIN yet. Please set it first.",
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: setattr(self.manager, "current", "set_mpin")
                    )
                ]
            )
            dialogMpin.open()
            return
        if mpin == saved_mpin:
            Snackbar(text="Login successful!", duration=1).open()
            self.manager.current = "home"
        else:
            dialogInvalid = MDDialog(
                title="Invalid MPIN",
                text="The MPIN you entered is incorrect.",
                buttons=[MDFlatButton(text="OK", on_release=lambda x: dialogInvalid.dismiss())]
            )
            dialogInvalid.open()
            self.on_pre_enter()

    def on_pre_enter(self):
        self.ids.mpin_input.text = ""
        self.ids.mpin_input.focus = False

class LoginApp(MDApp):
    def build(self):
        self.theme_cls.primary_palette = "Green"
        self.theme_cls.primary_hue = "500"
        self.theme_cls.theme_style = "Light"

        Window.bind(on_request_close=self.close_app)
        self.logged_in_username = None
        self.notification_count = 5

        root_widget = Builder.load_string(KV)

        # Check MPIN at startup
        username = "admin"  # or load last logged-in username from storage
        mpin, _ = get_user_mpin(username)
        if mpin and mpin.strip():
            Clock.schedule_once(lambda dt: self.change_screen_home("enter_mpin"), 0.1)
        else:
            Clock.schedule_once(lambda dt: self.change_screen_home("login"), 0.1)

        return root_widget

    def change_screen_home(self, screen_name):
        self.root.transition = SlideTransition(direction="left", duration=0.3)
        self.root.current = screen_name

    def change_screen(self, screen_name):
        self.root.transition = SlideTransition(direction="right", duration=0.3)
        self.root.current = screen_name

    def check_login(self, username, password):
        if verify_user(username, password):
            self.logged_in_username = username
            self.goto_home()
        else:
            MDDialog(title="Login Failed", text="Invalid username or password").open()

    def goto_home(self, *args):
        mpin, _ = get_user_mpin(self.logged_in_username)
        if not mpin or mpin.strip() == "":
            # First time MPIN setup
            dialog = MDDialog(
                title="Set MPIN?",
                text="You don't have an MPIN yet. Do you want to set it now?",
                buttons=[
                    MDFlatButton(text="No", on_release=lambda x: self.change_screen_home("home")),
                    MDRaisedButton(text="Yes", on_release=self.open_set_mpin_first_time)
                ]
            )
            dialog.open()
        else:
            self.change_screen_home("home")

    def open_set_mpin_first_time(self, *args):
        dialog.dismiss()
        screen = self.root.get_screen("set_mpin")
        screen.from_home = False  # first time MPIN
        self.change_screen_home("set_mpin")

    def go_to_set_mpin(self, from_home=False):
        """Call this when navigating to SetMPINScreen from Home or Menu"""
        screen = self.root.get_screen("set_mpin")
        screen.from_home = from_home
        self.change_screen_home("set_mpin")

    def refresh_login_card(self, *args):
        try:
            login_screen = self.root.get_screen("login")
            card = login_screen.ids.get("login_card")
            if card:
                e = card.elevation
                card.elevation = 0
                Clock.schedule_once(lambda dt: setattr(card, "elevation", e), 0.2)
        except Exception as ex:
            print("Card refresh failed:", ex)

    def logout(self, *args):
        def confirm_logout(*_):
            try:
                login_screen = self.root.get_screen("login")
                login_screen.ids.username.text = ""
                login_screen.ids.password.text = ""
            except Exception:
                pass
            self.change_screen_home("login")
            dialog.dismiss()

        def cancel_logout(*_):
            dialog.dismiss()

        dialog = MDDialog(
            title="Logout",
            text="Are you sure you want to log out?",
            buttons=[
                MDFlatButton(text="Cancel", on_release=cancel_logout),
                MDFlatButton(text="Yes", on_release=confirm_logout),
            ],
        )
        dialog.open()

    def close_app(self, *args):
        """Properly close the app when close button is pressed."""
        try:
            self.stop()
            Window.close()  # ensure the window closes on desktop
        except Exception as e:
            print("Error closing app:", e)

if __name__ == "__main__":
    LoginApp().run()