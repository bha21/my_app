import sqlite3, hashlib, os
from datetime import datetime, timedelta
from kivy.utils import platform

# ---------- DB PATH ----------
try:
    if platform == "android":
        from android.storage import app_storage_path
        DB_PATH = app_storage_path()
    else:
        DB_PATH = os.path.join(os.getcwd(), "data")
except ImportError:
    DB_PATH = os.path.join(os.getcwd(), "data")
os.makedirs(DB_PATH, exist_ok=True)

DB_NAME = os.path.join(DB_PATH, "users.db")

# ---------- DB HELPER ----------
def run_query(query, params=(), fetch=False):
    with sqlite3.connect(DB_NAME) as conn:
        cur = conn.cursor()
        cur.execute(query, params)
        return cur.fetchone() if fetch else None

# ---------- TABLE INIT ----------
run_query("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    mpin TEXT,
    mpin_set_date TEXT
)
""")

# ---------- FUNCTIONS ----------
hash_password = lambda pwd: hashlib.sha256(pwd.encode()).hexdigest()

def create_user(username, password):
    try:
        run_query(
            "INSERT INTO users (username, password_hash) VALUES (?, ?)",
            (username, hash_password(password))
        )
    except sqlite3.IntegrityError:
        print("User already exists.")

def verify_user(username, password):
    row = run_query(
        "SELECT password_hash FROM users WHERE username=?",
        (username,), fetch=True
    )
    return row and row[0] == hash_password(password)

def get_user_mpin(username):
    return run_query(
        "SELECT mpin, mpin_set_date FROM users WHERE username=?",
        (username,), fetch=True
    ) 

def set_user_mpin(username, mpin):
    run_query(
        "UPDATE users SET mpin=?, mpin_set_date=? WHERE username=?",
        (mpin, datetime.now().strftime("%Y-%m-%d"), username)
    )

def is_mpin_expired(set_date):
    return not set_date or datetime.now() > datetime.strptime(set_date, "%Y-%m-%d") + timedelta(days=90)

